package com.example.mvvmexample.db.dao;

import androidx.databinding.ObservableArrayList;
import androidx.lifecycle.LiveData;
import androidx.room.Dao;
import androidx.room.Delete;
import androidx.room.Insert;
import androidx.room.OnConflictStrategy;
import androidx.room.Query;
import androidx.room.Update;

import com.example.mvvmexample.model.Card;

import java.util.List;

@Dao
public interface CardDao {
    @Query("select * from cards")
    List<Card> loadAllCards();

    @Query("select * from cards")
    LiveData<List<Card>> loadAllLiveCards();

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    void insertAll(ObservableArrayList<Card> cardlist);

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    void insert(Card card);

    @Query("select count(*) from cards")
    int countCardsTuple();

    @Update
    void update(Card card);

    @Delete
    void delete(Card card);

    @Query("delete from cards")
    void deleteAll();
}
