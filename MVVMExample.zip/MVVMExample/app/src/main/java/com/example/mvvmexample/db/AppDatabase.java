package com.example.mvvmexample.db;

import android.content.Context;

import androidx.annotation.NonNull;
import androidx.room.Database;
import androidx.room.Room;
import androidx.room.RoomDatabase;
import androidx.room.migration.Migration;
import androidx.sqlite.db.SupportSQLiteDatabase;

import com.example.mvvmexample.db.dao.CardDao;
import com.example.mvvmexample.model.Card;

import static com.example.mvvmexample.Utility.AppExecutorsHelperKt.runOnDiskIO;

@Database(entities = {Card.class}, version = 1, exportSchema = false)
public abstract class AppDatabase extends RoomDatabase {
    private static volatile AppDatabase mInstance;
    public static final String DATABASE_NAME = "cards.db";

    public abstract CardDao cardDao();

    public static AppDatabase getInstance(final Context context) {
        if(mInstance == null) {
            synchronized (AppDatabase.class) {
                if(mInstance == null) {
                    mInstance = buildDatabase(context.getApplicationContext());
                }
            }
        }
        return mInstance;
    }

    private static AppDatabase buildDatabase(final Context context) {
        final AppDatabase build = Room.databaseBuilder(context, AppDatabase.class, DATABASE_NAME).
//                addCallback(new Callback() {
//                    @Override
//                    public void onCreate(@NonNull SupportSQLiteDatabase db) {
//                        super.onCreate(db);
//                        runOnDiskIO(() -> {
//
//                        });
//                    }
//                }).
                fallbackToDestructiveMigration().build();
        return build;
    }

    /*public static final Migration MIGRATION_1_2 = new Migration(1, 2) {
        @Override
        public void migrate(SupportSQLiteDatabase database) {
            // Create the new table
            database.execSQL("CREATE TABLE cards2 (name Text, phoneNumbers Text, PRIMARY KEY (phoneNumbers))");
            // Remove the old table
            database.execSQL("DROP TABLE cards");
            // Change the table name to the correct one
            database.execSQL("ALTER TABLE cards2 RENAME TO cards");
        }
    };*/
}
