package com.example.mvvmexample.adapter;

import android.view.LayoutInflater;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.mvvmexample.BR;
import com.example.mvvmexample.databinding.MainItemBinding;
import com.example.mvvmexample.model.Card;

import java.util.List;

public class MainRecyclerViewAdapter extends RecyclerView.Adapter<MainRecyclerViewAdapter.MainViewHolder> {
    private List<Card> mCardList;

    @NonNull
    @Override
    public MainViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        MainItemBinding mainItemBinding = MainItemBinding.inflate(LayoutInflater.from(parent.getContext()), parent, false);
        return new MainViewHolder(mainItemBinding);
    }

    @Override
    public void onBindViewHolder(@NonNull MainViewHolder holder, int position) {

        holder.bind(card);
    }

    @Override
    public int getItemCount() {
        return 0;
    }

    public void setItem(List<Card> cardList) {
        if(cardList == null) return;
        mCardList = cardList;
        notifyDataSetChanged();
    }

    public class MainViewHolder extends RecyclerView.ViewHolder {
        final MainItemBinding mMainItemBinding;

        public MainViewHolder(MainItemBinding mainItemBinding) {
            super(mainItemBinding.getRoot());
            this.mMainItemBinding = mainItemBinding;
        }

        void bind(Card card) {
            mMainItemBinding.setVariable(BR.carditem, card);
        }
    }
}
