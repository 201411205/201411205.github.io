package com.example.mvvmexample.adapter;

import androidx.databinding.BindingAdapter;
import androidx.databinding.ObservableArrayList;
import androidx.recyclerview.widget.RecyclerView;

import com.example.mvvmexample.model.Card;

public class AdapterBinding {
    @BindingAdapter("bind:item")
    public static void bindItem(RecyclerView recyclerView, ObservableArrayList<Card> cards) {
        MainRecyclerViewAdapter adapter = (MainRecyclerViewAdapter) recyclerView.getAdapter();
        if(adapter != null) {
            adapter.setItem(cards);
        }
    }
}
